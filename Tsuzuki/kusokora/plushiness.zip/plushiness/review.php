<?php 
include '_header.php';
?>


<div id="wrapper">
  <div id="featured-wrapper">
  

<?php

//emailが
$x=NULL;
$x=$_POST['x'];

if($x == NULL){
  //post から取得したxに何も値が入っていなければregisterから来たのだと判断
     //registerから来た場合Get actionでパラメーターを取得 
  $email=$_REQUEST["email"];
  $now=0;//registerから来てたら,nowは0

$con = mysql_connect('192.168.6.43', 'root', '');
  if (!$con) {
    exit('データベースに接続できませんでした。');
  }
  $result = mysql_select_db('itaro', $con);
  if (!$result) {
    exit('データベースを選択できませんでした。');
  }

  $result = mysql_query('SET NAMES utf8', $con);
  if (!$result) {
   exit('文字コードを指定できませんでした。');
  }
  $id = mysql_query("select id FROM user where mail='${email}'");
  while($data=mysql_fetch_array($id)){
    $id = $data["id"];//$idにuser_idを代入。
  }
  
}
else{
  //registerからきた場合以外は、api.phpのなかのPOSTアクションでパラメーターを取得
   include 'api.php'; //ここで記録してる
   $now=$now+1;
   print '<script>';?>
   function scroll() { 
      window.scrollTo(100,500); 
    } 
    window.onload=scroll;
<?php   print '</script>';
   if ($now==8){//8個目の動画ならredirect
$url='./result.php?mail='.${email};
print "<script language='javascript'>";
print "location.href='".${url}."'";
print "</script>";
   }
}

//echo $id;
if($x==NULL){
$count = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
$select = array(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);


$count[0] = mysql_query("select count(*) from review where(m_id=1)");
while($row = mysql_fetch_array($count[0],MYSQL_NUM)){
  if($row[0]==NULL)
    $row[0]=0;
  $count[0]=$row[0];
}
$count[1] = mysql_query("select count(*) from review where(m_id=2)");
while($row = mysql_fetch_array($count[1],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[1]=$row[0];
}
$count[2] = mysql_query("select count(*) from review where(m_id=3)");
while($row = mysql_fetch_array($count[2],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[2]=$row[0];
}
$count[3] = mysql_query("select count(*) from review where(m_id=4)");
while($row = mysql_fetch_array($count[3],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[3]=$row[0];
}
$count[4] = mysql_query("select count(*) from review where(m_id=5)");
while($row = mysql_fetch_array($count[4],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[4]=$row[0];
}
$count[5] = mysql_query("select count(*) from review where(m_id=6)");
while($row = mysql_fetch_array($count[5],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[5]=$row[0];
}
$count[6] = mysql_query("select count(*) from review where(m_id=7)");
while($row = mysql_fetch_array($count[6],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[6]=$row[0];
}
$count[7] = mysql_query("select count(*) from review where(m_id=8)");
while($row = mysql_fetch_array($count[7],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[7]=$row[0];
}
$count[8] = mysql_query("select count(*) from review where(m_id=9)");
while($row = mysql_fetch_array($count[8],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[8]=$row[0];
}
$count[9] = mysql_query("select count(*) from review where(m_id=10)");
while($row = mysql_fetch_array($count[9],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[9]=$row[0];
}
$count[10] = mysql_query("select count(*) from review where(m_id=11)");
while($row = mysql_fetch_array($count[10],MYSQL_NUM)){
  if($row[0]==NULL)
    $row[0]=0;
  $count[10]=$row[0];
}
$count[11] = mysql_query("select count(*) from review where(m_id=12)");
while($row = mysql_fetch_array($count[11],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[11]=$row[0];
}
$count[12] = mysql_query("select count(*) from review where(m_id=13)");
while($row = mysql_fetch_array($count[2],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[12]=$row[0];
}
$count[13] = mysql_query("select count(*) from review where(m_id=14)");
while($row = mysql_fetch_array($count[13],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[13]=$row[0];
}
$count[14] = mysql_query("select count(*) from review where(m_id=15)");
while($row = mysql_fetch_array($count[14],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[14]=$row[0];
}
$count[15] = mysql_query("select count(*) from review where(m_id=16)");
while($row = mysql_fetch_array($count[15],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[15]=$row[0];
}
$count[16] = mysql_query("select count(*) from review where(m_id=17)");
while($row = mysql_fetch_array($count[16],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[16]=$row[0];
}
$count[17] = mysql_query("select count(*) from review where(m_id=18)");
while($row = mysql_fetch_array($count[17],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[17]=$row[0];
}
$count[18] = mysql_query("select count(*) from review where(m_id=19)");
while($row = mysql_fetch_array($count[18],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[18]=$row[0];
}
$count[19] = mysql_query("select count(*) from review where(m_id=20)");
while($row = mysql_fetch_array($count[19],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[19]=$row[0];
}
$count[20] = mysql_query("select count(*) from review where(m_id=21)");
while($row = mysql_fetch_array($count[20],MYSQL_NUM)){
  if($row[0]==NULL)
    $row[0]=0;
  $count[20]=$row[0];
}
$count[21] = mysql_query("select count(*) from review where(m_id=22)");
while($row = mysql_fetch_array($count[21],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[21]=$row[0];
}
$count[22] = mysql_query("select count(*) from review where(m_id=23)");
while($row = mysql_fetch_array($count[22],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[22]=$row[0];
}
$count[23] = mysql_query("select count(*) from review where(m_id=24)");
while($row = mysql_fetch_array($count[23],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[23]=$row[0];
}
$count[24] = mysql_query("select count(*) from review where(m_id=25)");
while($row = mysql_fetch_array($count[24],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[24]=$row[0];
}
$count[25] = mysql_query("select count(*) from review where(m_id=26)");
while($row = mysql_fetch_array($count[25],MYSQL_NUM)){
    if($row[0]==NULL)
    $row[0]=0;
  $count[25]=$row[0];
}



//echo $count[0]."<br />";
//echo $count[1]."<br />";
//echo $count[2]."<br />";
//echo $count[3]."<br />";
//echo $count[4]."<br />";
//echo $count[5]."<br />";
//echo $count[6]."<br />";
//echo $count[7]."<br />";
//echo $count[8]."<br />";
//echo $count[9]."<br />";
//print "count[0]/10:".$count[0]/10;

while(true){
  $num=1;
  if((int)($count[0]/10)<$num){
    $select[0]=0;
  }
  if((int)($count[1]/10)<$num){
    $select[1]=0;
  }
  if((int)($count[2]/10)<$num){
    $select[2]=0;
  }
  if((int)($count[3]/10)<$num){
    $select[3]=0;
  }
  if((int)($count[4]/10)<$num){
    $select[4]=0;
  }
  if((int)($count[5]/10)<$num){
    $select[5]=0;
  }
  if((int)($count[6]/10)<$num){
    $select[6]=0;
  }
  if((int)($count[7]/10)<$num){
    $select[7]=0;
  }
  if((int)($count[8]/10)<$num){
    $select[8]=0;
  }
  if((int)($count[9]/10)<$num){
    $select[9]=0;
  }
  if((int)($count[10]/10)<$num){
    $select[10]=0;
  }
  if((int)($count[11]/10)<$num){
    $select[11]=0;
  }
  if((int)($count[12]/10)<$num){
    $select[12]=0;
  }
  if((int)($count[13]/10)<$num){
    $select[13]=0;
  }
  if((int)($count[14]/10)<$num){
    $select[14]=0;
  }
  if((int)($count[15]/10)<$num){
    $select[15]=0;
  }
  if((int)($count[16]/10)<$num){
    $select[16]=0;
  }
  if((int)($count[17]/10)<$num){
    $select[17]=0;
  }
  if((int)($count[18]/10)<$num){
    $select[18]=0;
  }
  if((int)($count[19]/10)<$num){
    $select[19]=0;
  }
  if((int)($count[20]/10)<$num){
    $select[20]=0;
  }
  if((int)($count[21]/10)<$num){
    $select[21]=0;
  }
  if((int)($count[22]/10)<$num){
    $select[22]=0;
  }
  if((int)($count[23]/10)<$num){
    $select[23]=0;
  }
  if((int)($count[24]/10)<$num){
    $select[24]=0;
  }
  if((int)($count[25]/10)<$num){
    $select[25]=0;
  }
  if ($select[0]*$select[1]*$select[2]*$select[3]*$select[4]*$select[5]*$select[6]*$select[7]*$select[8]*$select[9]*$select[10]*$select[11]*$select[12]*$select[13]*$select[14]*$select[15]*$select[16]*$select[17]*$select[18]*$select[19]*$select[20]*$select[21]*$select[22]*$select[23]*$select[24]*$select[25]==0){
    break;
  }
  $num=$num+1;
}


$number_of_past_data=0;
$id=1;
$existdata=NULL;
for($i=0;$i<26;$i++){
  if($select[$i]==0){
    //echo $i." was selected now.";
    $result=mysql_query("select id from review where m_id='${i}' and user_id='${id}'");
    while($row = mysql_fetch_array($result,MYSQL_NUM)){
      $existdata=$row[0];
    }
  //  echo $existdata;
    if ($existdata == NULL){
      break; //既に進んでいないことも分かり、ランダム選択の結果的にもOKなので確定する。
    }
    $number_of_past_data++;
    //number_of_past_data。
  }
}

if($number_of_past_data==26){
  $i=mt_rand(0,25);//全部のクラスをやっちゃった人にはランダムで与えてあげる。
}

$i=$i%26; //$selectが全部0の時iが27になってしまうので、それを回避するため.

$numbers=array($i+1);

$i=$i+26;
while($i<208){
  $numbers[]=$i+1;
  $i=$i+26;
}
//print_r($numbers);

for ($i=0;$i<count($numbers);$i++){
 /* ${random_number}=mt_rand(0,count(${numbers})-1);
  echo $random_number;
  //以下で$numbers[$i]と$numbres[$random_number]を交換
  ${temp}=${numbers[${i}]};
  ${numbers[${i}]}=${numbres[${random_number}]};
  ${numbres[${random_number}]}=${temp};*/
  //print " i=".$i;
  $random_number=mt_rand(0,(count($numbers)-1));
  //print " random_number:".$random_number;
  $temp=$numbers[$i];
  $numbers[$i]=$numbers[$random_number];
  $numbers[$random_number]=$temp;
}

}

//print_r($numbers);
$con = mysql_close($con);
if (!$con) {
  exit('データベースとの接続を閉じられませんでした。');
}

?>
<?php
//print_r($numbers);
$post_numbers=implode(",",$numbers);
print 'Count: '.($now+1).'/8<br>';
print "<video src='http://gemini.sys.es.osaka-u.ac.jp/~fabio/itaromovies/" ;
print $numbers[$now];
print ".mp4' autoplay controls width='400' height='300' muted=true ></video>";
//print_r($numbers);
?>
<canvas id="img" width="600" height="600"></canvas>
<?php
print "<form name='itarodata' action='review.php' method='post'>";
print "<input type='hidden' name='email' value='".$email."' >";
print "<input type='hidden' name='x' value='' >";
print "<input type='hidden' name='y' value='' >";
print "<input type='hidden' name='now' value=".($now)." >";
print "<input type='hidden' name='comment' value='' >";
print "<input type='hidden' name='playlist' value='".$post_numbers."' >";
//numbersとnumも送ったる.
print "</form>";

?>

<script>
$(function(){
      var canvas = document.getElementById("img");
      var context = canvas.getContext("2d");
      var imageObj = new Image();
      imageObj.onload = function() {
        context.drawImage(imageObj, 0, 0);
      };
imageObj.src = "/balance.png";
$("#img").click(function(evt) {

           var mouse={x:null,y:null};
           var img = document.getElementById("img");
           mouse.x = (evt.pageX - img.offsetLeft);
           mouse.y=(evt.pageY - img.offsetTop);
           context.globalAlpha=0.7;
           context.beginPath();
           context.fillStyle = "rgb(192, 80, 77)"; 
           context.font="10pt Arial"
           context.arc(mouse.x,mouse.y,5,0,Math.PI*2,false);
           context.fill();
           context.globalAlpha=1.0;
           context.fillStyle = "rgb(0,0,0)";
           context.fillText("n",mouse.x-4,mouse.y+4);
           if(window.confirm("Are you OK?")){
              var comment=prompt("Comment here!");
              if (comment.length==0){
                comment="_";
              }
              itarodata.x.value = (-300+mouse.x)/300.0;
              itarodata.y.value = (300-mouse.y)/300.0;
              itarodata.comment.value = comment;
              itarodata.submit();
          }
          else{
            window.alert("Deal is canceled")
            context.fillStyle = "blue"; 
            context.arc(mouse.x,mouse.y,5,0,Math.PI*2,false);
            context.fill();
            context.fillStyle = "white"; 
            context.font="10pt Arial"
            context.fillText("e",mouse.x-4,mouse.y+4);
          }
});


});


</script>
  </div>
</div>

<div id="copyright" class="container">
  <p>Copyright (c) 2013 Fabio Dalla Libera,Kusano Hitoshi All rights reserved. | Templates by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
</html>











