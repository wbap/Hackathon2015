<?php 
include '_header.php';
?>
<div id="wrapper">
	<div id="featured-wrapper">
	
		<div class="extra2 container">
			<div class="ebox1">
				<div class="hexagon"><span class="icon icon-lightbulb"></span></div>
				<div class="title">
					<h2>石黒研究室について</h2>
					<span class="byline">About Ishiguro Laboratory</span>
				</div>
				石黒研究室では，未来の人間社会を支える知的システムの実現を目指し，センサ工学，ロボット工学，人工知能，認知科学を基礎として，知覚情報基盤・知能ロボット情報基盤の研究開発、そしてこれらに基づき、人間と豊かにかかわる人間型ロボットを創成する研究に取り組んでいます。知覚情報基盤とは，多種のセンサからなるセンサネットワークを用いて，そこで活動する人間やロボットの知覚能力を補い，その活動を支援する情報基盤です．知能ロボット情報基盤とは，人間と直接相互作用することを通じ，ロボットの持つ多様なモダリティや存在感を活かした情報交換を行う情報基盤です．人間と豊かにかかわる人間型ロボットの開発は，「人間とは何か」という基本問題と常に密接な関係を持ちます。また街角や病院などの実社会の中に実験フィールドを構築し，人と関わるロボットの社会実験に積極的に取り組んでいます．ここで研究成果を実社会で検証するとともに，知的システムを応用した近未来の人間社会のあるべき姿を常に模索し続けながら研究を進めています．
				<br>
				<br>
				A Perceptual Information Infrastructure monitors and recognizes real environment through sensor networks. The sensor network tracks people in real-time and recognizes human behaviors which provide rich information for understanding real world events and helps peoples and robots working in the real world. An Interigent Robot Infrastructure is an interaction-based infrastructure. By interacting with robots, people can establish nonverbal communications with the artifical systems. That is, the purpose of a robot is to exist as a partner and to have valuable interactions with people.
   Our objective is to develop technologies for the new generation information infrastructures based on Computer Vision, Robotics and Artificial Intelligence.<br>
				<a href="register_user.php" class="button">ロボット占いを始める</a>
			</div>		

		</div>	
	</div>
</div>

<div id="copyright" class="container">
	<p>Copyright (c) 2013 Fabio Dalla Libera,Kusano Hitoshi All rights reserved. | Templates by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
</html>
