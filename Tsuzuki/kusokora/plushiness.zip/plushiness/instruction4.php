<?php 
include '_header.php';
$mail   = $_REQUEST['mail'];
$sex   = $_REQUEST['sex'];
$age   = $_REQUEST['age'];

print "<form name='userdata' action='register.php' method='post'>";
print "<input type='hidden' name='mail' value='".$mail."' >";
print "<input type='hidden' name='sex' value='".$sex."' >";
print "<input type='hidden' name='age' value='".$age."' >";
//numbersとnumも送ったる.
print "</form>";

print "<script>";
print '
$(function(){
$("#next").click(function(evt) {
              userdata.submit();
});
});

';

print "</script>";


?>
<div id="wrapper">
	<div id="featured-wrapper">
	
		<div class="extra2 container">
			<div class="ebox1">
				<div class="hexagon"><span class="icon icon-lightbulb"></span></div>
				<div class="title">
					<h2>ロボット占いのやり方</h2>
					<span class="byline">Instruction of Robot Fortune-Telling</span>
				</div>
<div>
4.Commentのボックスが出てくるので、ロボットの状態についてのコメントがあればここに書いてください。(泣いてる等)<br>	
<a href="./instruction_4.png"><img src="./instruction_4.png" width=300 height=450 ></a><br>
</div>				
<a id="next" class="button">Start</a>
							</div>		
		</div>	
	</div>
</div>

<div id="copyright" class="container">
	<p>Copyright (c) 2013 Fabio Dalla Libera,Kusano Hitoshi All rights reserved. | Templates by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
</html>
