<?php 

$x=$_POST['x'];
$y=$_POST['y'];
$comment=$_POST['comment'];
$email=$_POST['email'];
$numbers = explode(",",$_POST["playlist"]);
$now=$_POST['now'];
$num=$numbers[$now];

?>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php
$con = mysql_connect('192.168.6.43', 'root', '');
if (!$con) {
  exit('データベースに接続できませんでした。');
}

$result = mysql_select_db('itaro', $con);
if (!$result) {
  exit('データベースを選択できませんでした。');
}

$result = mysql_query('SET NAMES utf8', $con);
if (!$result) {
  exit('文字コードを指定できませんでした。');
}
$id = mysql_query("select id FROM user where mail='${email}'");
while($data=mysql_fetch_array($id)){
	$id = $data["id"];
}
$result = mysql_query("INSERT INTO review(user_id,m_id, x,y,comment) VALUES('$id','$num', '$x','$y','$comment')", $con);
//reloadして送信するとpostできるけど、redirect後にpostするとうまくいかん。。。
if (!$result) {
  exit('データを登録できませんでした。');
}
?>

</body>
</html>