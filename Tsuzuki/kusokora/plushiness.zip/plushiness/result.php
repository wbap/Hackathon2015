
<?php 
include '_header.php';
?>
<div id="wrapper">
  <div id="featured-wrapper">
  
    <div class="extra2 container">
<?php

function getRank($what, $thisVal){
  $result=mysql_query("select ".$what." from user where ".$what." is not null order by ".$what);
  $i=0;
  while($row = mysql_fetch_array($result,MYSQL_NUM)){
    $vals[$i]=$row[0];
    $i++;
  }
  //昇順にソート小さい物純
  $pos=-1;
  for($i=0;$i<count($vals);$i++){
    if ($thisVal<=$vals[$i]) {
      break;
    }
  }
  //print (count($vals)+1)."中".($i+1)."番目";
  $answer=(double)($i+1)/(count($vals)+1);
  //print "answer".$answer."<br>";
  return $answer;
}
$mail=$_REQUEST["mail"];

$con = mysql_connect('192.168.6.43', 'root', '');
if (!$con) {
  exit('データベースに接続できませんでした。');
}

$result = mysql_select_db('itaro', $con);
if (!$result) {
  exit('データベースを選択できませんでした。');
}

$result = mysql_query('SET NAMES utf8', $con);
if (!$result) {
  exit('文字コードを指定できませんでした。');
}

if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
     exit('メールアドレスがおかしいです。');
}

$result = mysql_query("select id FROM user where mail='${mail}'");
while($row = mysql_fetch_array($result,MYSQL_NUM)){
  $user_id=$row[0];
}

mysql_free_result($result);


$result = mysql_query("select m_id,x,y from review where user_id='${user_id}'");
$first=0;
$second=0;
$third=0;
$forth=0;
$first_num=0;
$second_num=0;
$third_num=0;
$forth_num=0;


while($row = mysql_fetch_array($result,MYSQL_NUM)){
  $x=$row[1];
  $y=$row[2];
  
  $avgxque= mysql_query("select avg(x) from review where m_id='${row[0]}'");
  $avgyque= mysql_query("select avg(y) from review where m_id='${row[0]}'");
  $avgx = mysql_fetch_array($avgxque,MYSQL_NUM);
  $avgy = mysql_fetch_array($avgyque,MYSQL_NUM);
  /*if($avgy[0]<0){
    print "x:".$x;
    print "y:".$y;
    print "avgx:".$avgx[0];
    print "avgy".$avgy[0]."<br>";
  }*/
  if ($avgx[0]>=0&&$avgy[0]>=0){
    $first_num = $first_num+1;
    $first = $first+($avgx[0]-$x)*($avgx[0]-$x)+($avgy[0]-$y)*($avgy[0]-$y);
  }
  
  else if ($avgx[0]<0&&$avgy[0]>=0){
    $second_num = $second_num+1;
    $second = $second+($avgx[0]-$x)*($avgx[0]-$x)+($avgy[0]-$y)*($avgy[0]-$y);
  }
  else if ($avgx[0]<0&&$avgy[0]<0){
    $third_num = $third_num+1;
    $third = $third+($avgx[0]-$x)*($avgx[0]-$x)+($avgy[0]-$y)*($avgy[0]-$y);
  }
  else if ($avgx[0]>=0&&$avgy[0]<0){
    $forth_num = $forth_num+1;
    $forth = $forth+($avgx[0]-$x)*($avgx[0]-$x)+($avgy[0]-$y)*($avgy[0]-$y);
  }


} 
  if($first_num==0){
    $first_num=1;
  }
  if($second_num==0){
    $second_num=1;
  }
    if($third_num==0){
    $third_num=1;
  }
    if($forth_num==0){
    $forth_num=1;
  }
  $first=$first/$first_num;
  $second=$second/$second_num;
  $third=$third/$third_num;
  $forth=$forth/$forth_num;
  //print "first:".$first;
  //print "second:".$second;
  //print "third:".$third;
  //print "forth:".$forth;
  mysql_query("update user set first='${first}',second='${second}',third='${third}',forth='${forth}' where id='${user_id}'");
  
    $firstScore=getRank("first",$first);//ある人のfirstが全員の中でどれぐらいの位置にあるのかを取得する。
    $secondScore=getRank("second",$second);//ある人のsecondが全員の中でどれぐらいの位置にあるのかを取得する。
    $thirdScore=getRank("third",$third);//ある人のthirdが全員の中でどれぐらいの位置にあるのかを取得する。
    $forthScore=getRank("forth",$forth);//ある人のforthが全員の中でどれぐらいの位置にあるのかを取得する。
/*print "first".$first."<br>";
print "first_num".$first_num."<br>";
print "second".$second."<br>";
print "second_num".$second_num."<br>";
print "third".$third."<br>";
print "third_num".$third_num."<br>";
print "forth".$forth."<br>";
print "forth_num".$forth_num."<br>";

print "firstScore".$firstScore."<br>";
print "secondScore".$secondScore."<br>";
print "thirdScore".$thirdScore."<br>";
print "forthScore".$forthScore."<br>";

*/


  $nature="あなたは";
  $affinity="あなたの相性のいい人は、";
   if ($firstScore+$secondScore>0.75){
        $nature.="周りの人のテンションにまったく乗らなく、周りが盛り上がってても、のれなくてしらけさせちゃったりしてるかも"."<br>";
        $affinity.="テンションが低く";
    }else if($firstScore+$secondScore>0.4){
      $nature.="周りの人のテンションになかなか乗らなく合わせることに疲れちゃったりすることが多いかも"."<br>";
      $affinity.="テンションがあまり高くなく";
    }else{
      $nature.="周りの人のテンションにちゃんと乗れちゃう。テンションを合わせてるつもりが、悪のりしちゃったりすることが多いかも。"."<br>";
      $affinity.="テンションが高く";
    }

    if ($firstScore+$forthScore>0.75){
        $nature.="そして、元気な人といると疲れてしまい、あまり得意ではありません。"."<br>";
        $affinity.="落ち着いていて";
    }else if($firstScore+$forthScore>0.4){
      $nature.="騒がしい人と一緒に居ることをなるべくさけ、落ち着いた人と一緒にいるとよいでしょう。"."<br>";
      $affinity.="穏やかで";

    }else{
      $nature.="元気な人と一緒にいると相乗効果でどんどん元気になれますが、バカップルになる可能性大なので注意です笑"."<br>";
      $affinity.="元気いっぱいで";
    }

    if ($secondScore+$thirdScore>0.75){
        $nature.="また、困っている人がいても無視しちゃってそうです。もうちょっと優しく生きてもいいかもね。。。"."<br>";
        $affinity.="抜け目がなく";
    }else if($secondScore+$thirdScore>0.4){
      $nature.="また、困っている人がいてもたまに見逃してるかもしれません。もうちょっと周りに気をつかうと幸せになれるかも。"."<br>";
      $affinity.="人並みにしっかりしていて";
    }else{
      $nature.="また、困ってる人がいたら放っておけません。ダメな子に捕まらないように注意してね！"."<br>";
      $affinity.="ちょっとどじだけど";
    }

       if ($thirdScore+$forthScore>0.75){
       // if (rand()<0.5){}
     $nature.="あなたはKYかもしれません。周りが静かにしてても、気付かず大騒ぎしてそう。図書館では注意してね！"."<br>";
     $affinity.="あなたを認めてくれるような人です。";
    }else if($secondScore+$thirdScore>0.4){
      $nature.="若干空気読めてない時があるかもテンションが低い人の前では騒がない方がいいかもね。。。"."<br>";
      $affinity.="あなたと競い合えるような人です。";
    }else{
      $nature.="人が落ち込んでいたらすぐ気づいて声をかけてあげれるひとです。あなたなら、思わぬところに出会いがあるかもしれません。"."<br>";
      $affinity.="あなたが放っておけないような人です。";
    }

       if ($firstScore+$secondScore+$thirdScore+$forthScore>2.5){
     $nature.="<br>"."全体的にあなたは雰囲気が読めてないことが多いかも。注意してね！"."<br>";
    }else if($firstScore+$secondScore+$thirdScore+$forthScore>1.5){
      $nature.="<br>"."全体的にあなたはまあまあ空気をあわせれる人です。はめを外して浮いちゃわないように注意しましょう。"."<br>";
    }else{
      $nature.="<br>"."全体的にあなたはみんなの心を簡単に読めてしまう。その能力をみんなのために使ってあげてね！"."<br>";
    }
print "<h1>結果</h1>";
    print "<br>人間性<br>".$nature."<br><br>";    
    print "相性のいい人<br>".$affinity."<br><br>";
    print '<br>ご協力ありがとうございました！！<br>';
    print '<a href="review.php?email='.$mail.'" class="button">もう一回やってみる</a>';
 
  $con = mysql_close($con);


if (!$con) {
  exit('データベースとの接続を閉じられませんでした。');
}
?>

    </div>  
  </div>
</div>

<div id="copyright" class="container">
  <p>Copyright (c) 2013 Fabio Dalla Libera,Kusano Hitoshi All rights reserved. | Templates by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
</html>




