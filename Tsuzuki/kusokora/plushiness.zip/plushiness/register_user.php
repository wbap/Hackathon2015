<?php 
include '_header.php';
?>
<div id="wrapper">
	<div id="featured-wrapper">
	
		<div class="extra2 container">
			<div class="ebox1">
				<div class="hexagon"><span class="icon icon-lightbulb"></span></div>
				<div class="title">
					<h2>ロボット占いを始める</h2>
					<span class="byline">Instruction of Robot Fortune-Telling</span>
				</div>
以下のフォームを埋めて頂き、送信を押すと占いがスタートします。<br>
<form action="instruction1.php" method="post">
  メールアドレス<br>
  <input type="text" name="mail"><br>
性別<br>
<input type="radio" name="sex" value="0"> 男
<input type="radio" name="sex" value="1"> 女
<br>
  年齢<br>
  <input type="text" name="age"><br>

  <input type="submit">
  
</form>

		</div>	
	</div>
</div>

<div id="copyright" class="container">
	<p>Copyright (c) 2013 Fabio Dalla Libera,Kusano Hitoshi All rights reserved. | Templates by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
</html>
